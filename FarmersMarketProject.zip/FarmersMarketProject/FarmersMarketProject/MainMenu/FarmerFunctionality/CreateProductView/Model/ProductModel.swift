import UIKit

struct ProductModel: Codable {
    var product: Int
    var available_quantity: Int
    var price: Int
}



import UIKit

struct TableProductListingCellModel: Codable {
    var id: Int
    var farmer_name: String
    var product: Int
    var available_quantity: Int
    var price: String
}

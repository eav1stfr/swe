import UIKit

final class ProductCategoriesViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}

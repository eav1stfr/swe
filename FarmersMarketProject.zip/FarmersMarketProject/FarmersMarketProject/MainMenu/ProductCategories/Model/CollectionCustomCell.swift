import UIKit

struct ProductCategoriesModel {
    var imageName: String
    var nameOfCategory: String
}

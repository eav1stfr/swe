import UIKit

struct TableCellModel {
    var imageName: String
    var description: String
}

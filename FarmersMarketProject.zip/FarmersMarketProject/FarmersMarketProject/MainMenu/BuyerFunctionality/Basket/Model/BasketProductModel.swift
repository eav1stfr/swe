import UIKit

struct BasketProductModel {
    var productName: String
    var productPrice: String
    var productQuantity: String
    var farmerName: String
}

